import{p as l}from"./propiedades.CZRUa7Jv.js";const s=document.getElementById("resultados"),n=document.getElementById("buscar");n.addEventListener("click",function(){d()});function d(){s.innerHTML="<p>Buscando...</p>";const t=document.querySelectorAll("select"),i=t[0].value,o=t[1].value,c=t[2].value,r=l.filter(e=>{let a=!0;return i&&(console.log(e.categoriaGraphql.categoria,i),a=e.categoriaGraphql.categoria[0]===i,!a)||o&&(a=e.direccion.ciudad===o,!a)||c&&(a=e.operacion.operacion===c,!a)?!1:a});s.innerHTML="",r.length===0?s.innerHTML="<div class='text-center p-4'><p class='text-gray-500'>No se encontraron resultados para los criterios seleccionados</p></div>":r.forEach(e=>{s.innerHTML+=`
          <a href="/propiedades/${e.slug}" class="col-span-1">
            <div class="card bg-base-100 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <figure class="relative">
                <img
                  src="https://marsolpropiedades.cl/images/propiedades/${e.slug}/1.webp"
                  alt={propiedad.direccion.direccion}
                  class="w-full object-cover"
                  style="height: 200px;"
                />
                <div class="card-body bg-gradient-to-t from-black/80 to-transparent absolute bottom-0 w-full p-4">
                  <div class="badge border-none text-white bg-red-700 px-2 w-fit">
                    ${e.precio.precio?`$${e.precio.precio} CLP`:`${e.precio.precioUf} UF`}
                  </div>
                </div>
              </figure>
              <div class="bg-gray-100 px-2 py-1">${e.categoriaGraphql.categoria} en ${e.operacion.operacion}</div>
              <div class="card-body p-0">
                <ul class="list">
                  <li class="list-row flex flex-col gap-1 h-20">
                    <header class="overflow-hidden text-ellipsis">
                      <h2 class="card-title">${e.direccion.direccion}</h2>
                    </header>
                    <div class="flex justify-center items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-geo-alt" viewBox="0 0 16 16">
  <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10"/>
  <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
</svg>
                      <p>${e.direccion.ciudad}</p>
                    </div>
                  </li>
                  <li class="list-row p-2">
                    <div class="justify-end">
                      <div class="grid gap-1">
                        <div>
                          ${e.datos.areaTotal?`<div class="tooltip" data-tip="Área total"><span class="badge bg-red-400 hover:bg-red-700 border-none text-white text-xs">${e.datos.areaTotal} m²</span></div>`:""} 
                          ${e.datos.banos?`<div class="tooltip" data-tip="Baños"><span class="badge bg-red-400 hover:bg-red-700 border-none text-white text-xs">${e.datos.banos} Bañ.</span></div>`:""}
                          ${e.datos.habitaciones?`<div class="tooltip" data-tip="Dormitorios"><span class="badge bg-red-400 hover:bg-red-700 border-none text-white text-xs">${e.datos.habitaciones} Dorm.</span></div>`:""}
                          ${e.incluye.estacionamiento?'<div class="tooltip" data-tip="Estacionamiento"><span class="badge bg-red-400 hover:bg-red-700 border-none text-white text-xs">Estac.</span></div>':""}
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </a>
        `})}

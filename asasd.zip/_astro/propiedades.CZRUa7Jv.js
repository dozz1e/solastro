const r=await fetch("https://marsolpropiedades.cl/data/graphql",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`{
      propiedades(where: {categoryId: 2}, first: 100) {
        nodes {
          title
          slug
          precio {
            precio
            precioUf
          }
          operacion {
            operacion
          }
          incluye {
            incluye
          }
          espaciosComunes {
            espaciosComunes
          }
          direccion {
            ciudad
            direccion
          }
          detallesAdicionales {
            detalles
          }
          datos {
            areaTotal
            banos
            habitaciones
            galeria
          }
          categoriaGraphql {
            categoria
          }
          seo {
            metaKeywords
            metaDesc
            title
          }
          categories {
            nodes {
              categoryId
            }
          }
        }
      }
    }`})});if(!r.ok)throw new Error("Problemas con la conexión");const s=await r.json(),a=s.data.propiedades.nodes;a.filter(e=>e.categories.nodes.some(t=>t.categoryId===11)?e:!1);a.slice(0,8);let o=a.map(e=>e.categoriaGraphql.categoria[0]);o=[...new Set(o)];let i=a.map(e=>e.direccion.ciudad);i=[...new Set(i)];[...o];export{a as p};
